package com.vti.shopee.controller;

import com.vti.shopee.model.Product;
import com.vti.shopee.model.ResponseObject;
import com.vti.shopee.repository.ProductRepository;
import com.vti.shopee.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/v1/product")
public class ProductController {
    @Autowired
    ProductRepository productRepository;
    @Autowired
    ProductService productService;

    @PostMapping("/insert")
    Product insert(@RequestBody Product product){
        return productRepository.save(product);
    }
    @PutMapping("/{id}")
    ResponseEntity<ResponseObject> update(@RequestBody Product newProduct,@PathVariable Long id)
    {
        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            Product product = new Product();
            product.setName(newProduct.getName());
            product.setCreateDate(newProduct.getCreateDate());
            product.setPrice(newProduct.getPrice());
            product.setUrl(newProduct.getUrl());
            product.setActive(newProduct.isActive());

            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("Ok", "Insert product successfully",
                            productRepository.save(product)));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("Ok", "Product not found", ""));

    }
    @DeleteMapping("/{id}")
    ResponseEntity<ResponseObject> deleteProduct(@PathVariable Long id)
    {
        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            productRepository.deleteById(id);
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseObject("Ok", "Success", foundProduct.get()));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseObject("Ok", "Product not found", ""));
    }
    @GetMapping("/name")
    ResponseEntity<ResponseObject> getProductByName(@RequestParam String name)
    {
        List<Product> productList = productService.getProductByName(name);
        if (productList.size()==0){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).
                    body(new ResponseObject("Ok","Product Name not found"," "));
        }
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("Ok","Success",productList));

    }
    @GetMapping("/{id}")
    ResponseEntity<ResponseObject> getProductByID(@PathVariable Long id) {
        Optional<Product> foundProduct = productRepository.findById(id);
        if (foundProduct.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("OK", "success", foundProduct));

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok", "product not found", ""));
    }
    @GetMapping(" ")
    List<Product> getAllProductActive(){
        boolean isActive;
        if(isActive = false){
            return  null;
        }
            List<Product> productList = productRepository.findAll();
            return productList;


    }
    @GetMapping("/{price}")
    ResponseEntity<ResponseObject> getProductByTop(@RequestParam Double price)
    {
        List<Product> productList = productService.getProductByTop(price);
        if (productList.size()==0){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).
                    body(new ResponseObject("Ok","Product Name not found"," "));
        }
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("Ok","Success",productList));

    }

}
