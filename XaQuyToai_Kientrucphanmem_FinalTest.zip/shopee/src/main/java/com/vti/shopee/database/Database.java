package com.vti.shopee.database;

import com.vti.shopee.model.Product;
import com.vti.shopee.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

@Configuration
public class Database {
    @Bean
    CommandLineRunner initDatabase(ProductRepository productRepository) {
        return new CommandLineRunner() {
            @Override
            public void run(String... args) throws Exception {
//                Product p1 = new Product("Shirt1",new Date(),100.0,"https://badhabitsstore.vn/collections/shirt",true);
//                productRepository.save(p1);
//                Product p2 = new Product("Shirt2",new Date(),99.0,"https://badhabitsstore.vn/collections/shirt",true);
//                productRepository.save(p2);
//                Product p3 = new Product("Shirt3",new Date(),98.0,"https://badhabitsstore.vn/collections/shirt",true);
//                productRepository.save(p3);
            }
        };
    }
}
