package com.vti.shopee.service;

import com.vti.shopee.model.Product;
import com.vti.shopee.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.List;

@Service
@Configurable
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> getProductByName(String keyword)
    {
        List<Product> returnList = new ArrayList<>();

        for (Product product : productRepository.findAll())
        {
            if (product.getName().toLowerCase().trim().replace(" ","").
                    contains(keyword.toLowerCase().trim().replace(" ","")))
            {
                returnList.add(product);
            }
        }
        return returnList;
    }

    public List<Product> getProductByTop(Double price)
    {
        List<Product> returnList = new ArrayList<>();

        for (Product product : productRepository.findAll())
        {
            if (product.getPrice() > 100)
            {
                returnList.add(product);
            }
        }
        return returnList;
    }


}