package vtiedu.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import vtiedu.management.model.Driver;
import vtiedu.management.repository.DriverRepository;

import java.util.ArrayList;
import java.util.List;

@Service
@Configurable
public class DriverService {

    @Autowired
    private DriverRepository driverRepository;

    public List<Driver> searchDriverByName(String keyword)
    {
        List<Driver> returnList = new ArrayList<>();

        for (Driver driver : driverRepository.findAll())
        {
            if (driver.getName().toLowerCase().trim().replace(" ","").
                    contains(keyword.toLowerCase().trim().replace(" ","")))
            {
                returnList.add(driver);
            }
        }
        return returnList;
    }

}
