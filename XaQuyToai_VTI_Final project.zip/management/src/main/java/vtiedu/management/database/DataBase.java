package vtiedu.management.database;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import vtiedu.management.model.Driver;
import vtiedu.management.repository.DriverRepository;

@Configuration
public class DataBase {
    @Bean
    CommandLineRunner initDatabase(DriverRepository driverRepository) {
        return new CommandLineRunner() {
            @Override
            public void run(String... args) throws Exception {
                Driver d1 = new Driver("Tung Chi","TP HCM",true);
                Driver d2 = new Driver("Tung Ch","TP HCM",true);
                Driver d3 = new Driver("Tung C","TP HCM",true);
                Driver d4 = new Driver("Tung","TP HCM",true);
                driverRepository.save(d1);
                driverRepository.save(d2);
                driverRepository.save(d3);
                driverRepository.save(d4);

            }
        };
    }
}
