package vtiedu.management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import vtiedu.management.model.Driver;
import vtiedu.management.model.ResponseObject;
import vtiedu.management.repository.DriverRepository;
import vtiedu.management.service.DriverService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/v1/driver")
public class DriverController {
    @Autowired
    DriverRepository driverRepository;
    @Autowired
    DriverService driverService;
    @GetMapping("")
    List<Driver> getListDriver(){
        List<Driver> driverList = driverRepository.findAll();
        return driverList;
    }
    @GetMapping("/{id}")
    ResponseEntity<ResponseObject> getStudentInfo(@PathVariable Long id) {
        Optional<Driver> foundStudent = driverRepository.findById(id);
        if (foundStudent.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).
                    body(new ResponseObject("OK", "success", foundStudent));

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).
                body(new ResponseObject("ok", "student not found", ""));
    }

    @GetMapping("/name")
        ResponseEntity<ResponseObject> searchDriverByName(@RequestParam String name)
    {
        List<Driver> driverList = driverService.searchDriverByName(name);
        if (driverList.size()==0){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).
                    body(new ResponseObject("ok","Student Name not found"," "));
        }
        return ResponseEntity.status(HttpStatus.OK).
                body(new ResponseObject("ok","success",driverList));

    }

    @PostMapping("/insertdriver")
    Driver insert (@RequestBody Driver driver){
        return driverRepository.save(driver);
    }

}
